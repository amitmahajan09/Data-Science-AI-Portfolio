# **App Name**: GST Reconciliation Ace

## Core Features:

- Dynamic Column Mapping: Allow users to map columns from uploaded files to standard application fields using a drag-and-drop or dropdown interface, persisting the mapping for future uploads.
- Secure File Upload: Enable secure file uploads for .csv and .xlsx formats, processing and storing data in the database isolated by Organization ID and Upload Batch ID.
- Reconciliation Logic: Implement the reconciliation process based on Supplier GSTIN and Invoice Number. The LLM tool will decide to alert based on date/value tolerance (+/-).
- Interactive Dashboard: Create a main dashboard displaying key reconciliation metrics, total invoices uploaded, matched, mismatched and invoices missing. Displayed data is only from the latest batch.
- Interactive Report Table: Develop a sortable, filterable, and searchable table for reconciliation results, allowing users to filter by Mismatch Type (Missing, Mismatch, Extra) with .xlsx export.
- User Authentication: Establish role-based access control with Super Admin, Admin, and User roles, providing secure signup and access management, governed by licensing terms (trial/paid).
- Payment Gateway: Stripe Payment Gateway Integration for subscription handling (Monthly/Yearly) to enable license activation/deactivation.

## Style Guidelines:

- Primary color: Strong blue (#4285F4), reminiscent of reliability and trust.
- Background color: Very light blue (#E3F2FD), providing a calm backdrop to the detailed financial data. It is related in hue to the primary color, but greatly desaturated for a background feel.
- Accent color: Complementary violet (#90CAF9), for interactive elements and key highlights.
- Body and headline font: 'Inter' (sans-serif), for a modern, machined, objective, neutral look, easy to read in the tabular data.
- Use clean, professional icons to represent different categories and actions, with a focus on clarity.
- Emphasize a clear, structured layout for data tables and reports, ensuring readability and easy navigation.
- Implement subtle transitions and animations to enhance user experience without being distracting.