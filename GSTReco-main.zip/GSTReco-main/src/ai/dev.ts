import { config } from 'dotenv';
config();

import '@/ai/flows/reconciliation-alerts.ts';
import '@/ai/flows/smart-search-flow.ts';
