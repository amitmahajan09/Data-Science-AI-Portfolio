'use server';

/**
 * @fileOverview Analyzes a batch of reconciliation mismatches and generates prioritized alerts based on severity and potential impact.
 *
 * - reconciliationAlerts - A function that handles the batch reconciliation analysis and alert generation.
 * - ReconciliationAlertsInput - The input type for the reconciliationAlerts function.
 * - ReconciliationAlertsOutput - The return type for the reconciliationAlerts function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const MismatchDataSchema = z.object({
  supplierGstin: z.string().describe('Supplier GSTIN.'),
  documentNumber: z.string().describe('Invoice Number.'),
  internalTaxableValue: z.number().describe("Taxable value from the client's internal system."),
  gst2bTaxableValue: z.number().describe('Taxable value from the GSTR-2B data. Will be 0 if missing in 2B.'),
  internalInvoiceDate: z.string().describe("Invoice date from the client's internal system (YYYY-MM-DD)."),
  gst2bInvoiceDate: z.string().describe('Invoice date from the GSTR-2B data (YYYY-MM-DD). Will be empty if missing in 2B.'),
});

const ReconciliationAlertsInputSchema = z.object({
  mismatches: z.array(MismatchDataSchema),
  dateToleranceDays: z.number().describe('The number of days of date tolerance allowed.'),
  valueTolerancePercentage: z.number().describe('The percentage of value tolerance allowed.'),
  orgId: z.string().describe('The ID of the organization.'),
  apiKey: z.string().optional().describe('The user-provided Gemini API key.'),
});
export type ReconciliationAlertsInput = z.infer<typeof ReconciliationAlertsInputSchema>;


const AlertSchema = z.object({
    documentNumber: z.string().describe('The invoice number this alert corresponds to.'),
    alertPriority: z.enum(['High', 'Medium', 'Low', 'None']).describe('The priority of the alert based on the severity and potential impact of discrepancies.'),
    alertMessage: z.string().describe('A message describing the discrepancy and its potential impact.'),
});

const ReconciliationAlertsOutputSchema = z.object({
    alerts: z.array(AlertSchema),
});
export type ReconciliationAlertsOutput = z.infer<typeof ReconciliationAlertsOutputSchema>;


const reconciliationPrompt = ai.definePrompt({
  name: 'reconciliationPrompt',
  input: { schema: ReconciliationAlertsInputSchema },
  output: { schema: ReconciliationAlertsOutputSchema },

  prompt: `You are an expert reconciliation analyst, skilled in identifying and prioritizing discrepancies between a client's internal purchase data and the official GSTN GSTR-2B data.

You will be given a JSON array of reconciliation mismatches. Analyze each mismatch in the array and for each one, determine the priority of the alert (High, Medium, Low, or None) and generate a concise message describing the discrepancy and its potential impact.

Consider the following factors when determining the alert priority for each item:
- Date Tolerance: The allowed difference in days between the internal invoice date and the GSTR-2B invoice date. Use the provided dateToleranceDays field.
- Value Tolerance: The allowed percentage difference between the internal taxable value and the GSTR-2B taxable value. Use the provided valueTolerancePercentage field.
- Significance of Discrepancy: A large value difference or a missing invoice in GSTR-2B (where GSTR-2B value is 0) should be considered high priority.
- Date Difference: A date difference exceeding the tolerance should be considered at least medium priority.

Here are the global tolerance settings:
Date Tolerance (Days): {{{dateToleranceDays}}}
Value Tolerance (%): {{{valueTolerancePercentage}}}
Organization ID: {{{orgId}}}

Here is the JSON array of mismatches to analyze:
{{{json stringify=mismatches}}}

Respond with a single JSON object containing a single key "alerts". The value of "alerts" should be an array of objects, where each object contains the original documentNumber, the determined alertPriority, and the generated alertMessage.
Ensure that the alertMessage provides a concise explanation of the discrepancy and its potential impact on the client.
It is crucial that the output array has the exact same number of items as the input array. For each input item, produce one alert object.

Example Input Mismatch Item:
{
  "supplierGstin": "29ABCDE1234F1Z5",
  "documentNumber": "INV-001",
  "internalTaxableValue": 1000,
  "gst2bTaxableValue": 0,
  "internalInvoiceDate": "2023-04-15",
  "gst2bInvoiceDate": ""
}

Example Output Alert Item:
{
  "documentNumber": "INV-001",
  "alertPriority": "High",
  "alertMessage": "Invoice missing in GSTR-2B. Potential ITC loss."
}
`,
});

const reconciliationFlow = ai.defineFlow(
  {
    name: 'reconciliationFlow',
    inputSchema: ReconciliationAlertsInputSchema,
    outputSchema: ReconciliationAlertsOutputSchema,
  },
  async (input) => {
    // Note: We are dynamically configuring the prompt with the user's API key.
    // This is a temporary solution for this context. In a real app,
    // you'd likely use a more robust multi-tenancy auth solution.
    const { output } = await reconciliationPrompt(input, {
      config: {
        model: {
          apiKey: input.apiKey || process.env.GEMINI_API_KEY
        }
      }
    });
    return output || { alerts: [] };
  }
);

export async function reconciliationAlerts(input: ReconciliationAlertsInput): Promise<ReconciliationAlertsOutput> {
  return reconciliationFlow(input);
}
