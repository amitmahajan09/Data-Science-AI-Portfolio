'use server';
/**
 * @fileOverview A flow that converts a natural language query into structured search filters for reconciliation reports.
 * 
 * - smartSearch - A function that takes a user's query and returns a structured filter object.
 * - SmartSearchInput - The input type for the smartSearch function.
 * - SmartSearchOutput - The return type for the smartSearch function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'zod';

const SmartSearchInputSchema = z.object({
  query: z.string().describe('The natural language search query from the user.'),
  today: z.string().describe('The current date in YYYY-MM-DD format, to help resolve relative date queries like "last month".'),
  apiKey: z.string().optional().describe('The user-provided Gemini API key.'),
});
export type SmartSearchInput = z.infer<typeof SmartSearchInputSchema>;

const SmartSearchOutputSchema = z.object({
    status: z.array(z.enum(['Matched', 'Mismatched', 'Missing in 2B', 'Extra in 2B'])).optional().describe('Filter by reconciliation status.'),
    amountGreaterThan: z.number().optional().describe('Filter for taxable values greater than this amount.'),
    amountLessThan: z.number().optional().describe('Filter for taxable values less than this amount.'),
    startDate: z.string().optional().describe('The start of the date range to filter by, in YYYY-MM-DD format.'),
    endDate: z.string().optional().describe('The end of the date range to filter by, in YYYY-MM-DD format.'),
    supplierGstin: z.string().optional().describe('Filter by a specific supplier GSTIN.'),
    documentNumber: z.string().optional().describe('Filter by a specific invoice or document number.'),
    textSearch: z.string().optional().describe('A generic text search term if no other specific criteria can be extracted. Use for names or other free text.'),
});
export type SmartSearchOutput = z.infer<typeof SmartSearchOutputSchema>;

const searchPrompt = ai.definePrompt({
    name: 'smartSearchPrompt',
    input: { schema: SmartSearchInputSchema },
    output: { schema: SmartSearchOutputSchema },

    prompt: `You are an expert at converting natural language search queries into structured JSON filters for a financial reconciliation tool.

The user will provide a query. Your task is to analyze it and extract the relevant filtering criteria. Today's date is {{{today}}}.

Here are the possible filter fields:
- status: Can be one or more of 'Matched', 'Mismatched', 'Missing in 2B', 'Extra in 2B'.
- amountGreaterThan: For queries like "over 10000", "more than 5k".
- amountLessThan: For queries like "under 500", "less than 1000".
- startDate / endDate: For date ranges. Interpret relative dates like "last month", "this year", "yesterday" based on the current date.
- supplierGstin: If the query looks like a GSTIN (e.g., starts with 2 digits, is 15 characters long).
- documentNumber: If the query looks like an invoice number.
- textSearch: For any other text that could be a supplier name or a general keyword.

Examples:
- Query: "show me all mismatched invoices" -> { "status": ["Mismatched"] }
- Query: "extra invoices from last month" -> { "status": ["Extra in 2B"], "startDate": "YYYY-MM-01", "endDate": "YYYY-MM-DD" } (calculated based on today's date)
- Query: "invoices over 50000" -> { "amountGreaterThan": 50000 }
- Query: "innovate inc" -> { "textSearch": "innovate inc" }
- Query: "29ABCDE1234F1Z5" -> { "supplierGstin": "29ABCDE1234F1Z5" }
- Query: "missing invoices from Q1" -> { "startDate": "YYYY-01-01", "endDate": "YYYY-03-31" } (assuming current year)

User Query: "{{{query}}}"

Based on this query, generate the JSON filter object. Only include fields that are specified in the query. Do not make up values. If a query contains a value like "5k", convert it to 5000.
If you cannot extract any structured information, return an empty object.
`,
});


const smartSearchFlow = ai.defineFlow(
  {
    name: 'smartSearchFlow',
    inputSchema: SmartSearchInputSchema,
    outputSchema: SmartSearchOutputSchema,
  },
  async (input) => {
    const { output } = await searchPrompt(input, {
        config: {
            model: {
            apiKey: input.apiKey || process.env.GEMINI_API_KEY
            }
        }
    });
    return output || {};
  }
);


export async function smartSearch(input: SmartSearchInput): Promise<SmartSearchOutput> {
    return smartSearchFlow(input);
}
