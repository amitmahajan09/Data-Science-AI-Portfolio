/**
 * @fileoverview This file initializes the Genkit AI instance and configures the plugins.
 * It is designed to allow dynamic configuration, such as passing API keys at runtime.
 */
import {genkit} from 'genkit';
import {googleAI} from '@genkit-ai/google-genai';
import {config} from 'dotenv';

config();

export const ai = genkit({
  plugins: [
    googleAI({
      apiKey: process.env.GEMINI_API_KEY,
    }),
  ],
});
