

'use server'

// import { reconciliationAlerts } from "@/ai/flows/reconciliation-alerts";
// import { smartSearch } from "@/ai/flows/smart-search-flow";
import { getReconciliationRun, getReconciliationRuns, saveReconciliationRun } from "@/lib/mock-db";
import type { ColumnMapping, Invoice, ReconciliationOutput, ReconciliationResult, SavedReconciliationRun } from "@/lib/types";
import { differenceInDays, parse, isValid, format } from "date-fns";
import Papa from "papaparse";
import * as XLSX from 'xlsx';

// --- Reconciliation Logic ---

const parseDate = (dateValue: string | number | Date): string | null => {
    if (dateValue === null || dateValue === undefined || dateValue === '') return null;

    // If it's already a valid date object, format it.
    if (dateValue instanceof Date) {
        if (isValid(dateValue)) {
            return format(dateValue, 'yyyy-MM-dd');
        }
        return null;
    }
    
    // Handle Excel serial date number if string parsing fails or it's a number
    if (typeof dateValue === 'number') {
         if (dateValue > 0) {
            // The `XLSX.SSF.parse_date_code` function is reliable for Excel dates.
            // It returns a struct with year, month, day, etc.
            const dateInfo = XLSX.SSF.parse_date_code(dateValue);
            if (dateInfo && dateInfo.y && dateInfo.m && dateInfo.d) {
                // Month is 0-indexed in JS Date, but 1-indexed in dateInfo
                const parsedDate = new Date(Date.UTC(dateInfo.y, dateInfo.m - 1, dateInfo.d, dateInfo.H, dateInfo.M, dateInfo.S));
                 if (isValid(parsedDate)) {
                    return format(parsedDate, 'yyyy-MM-dd');
                }
            }
        }
    }

    // Try parsing as a string last, as it's the most common format.
    if (typeof dateValue === 'string') {
        const dateString = dateValue.trim();
        // A list of formats to try, from most to least specific.
        // 'yy' handles 2-digit years correctly, assuming the 21st century.
        const formats = [
            "yyyy-MM-dd'T'HH:mm:ss.SSSX", // ISO with timezone
            'yyyy-MM-dd', 
            'dd-MM-yyyy', 
            'MM/dd/yyyy', 
            'dd/MM/yyyy',
            'M/d/yyyy',
            'MM-dd-yy',
            'MM/dd/yy', 
            'dd-MM-yy',
            'M/d/yy', 
            'dd-MMM-yy', 
        ];

        for (const fmt of formats) {
            const parsedDate = parse(dateString, fmt, new Date());
            if (isValid(parsedDate)) {
                return format(parsedDate, 'yyyy-MM-dd');
            }
        }
    }

    // Fallback for when no format matches
    console.warn(`Could not parse date with any known method: ${dateValue}`);
    // Attempt to return the string value if it was one, otherwise null
    return typeof dateValue === 'string' ? dateValue : null;
}


const parseFile = (fileBuffer: ArrayBuffer, mapping: ColumnMapping, fileName: string): Invoice[] => {
    let jsonData: any[];
    const isExcel = fileName.endsWith('.xlsx') || fileName.endsWith('.xls');

    if (isExcel) {
        // For Excel, read with `cellDates: false` to let our robust parser handle it.
        const workbook = XLSX.read(fileBuffer, { type: 'array', cellDates: false });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        // `raw: true` gets the underlying values (numbers for dates), which `parseDate` can handle.
        jsonData = XLSX.utils.sheet_to_json(worksheet, { raw: true, defval: null });
    } else {
        const text = new TextDecoder('utf-8').decode(fileBuffer);
        const papaResult = Papa.parse(text, {
            header: true,
            skipEmptyLines: true,
            transformHeader: h => h.trim(),
        });
        if (papaResult.errors.length > 0) {
            throw new Error(`Failed to parse CSV: ${papaResult.errors.map(e => e.message).join(', ')}`);
        }
        jsonData = papaResult.data;
    }

    const mappedData = jsonData.map((row: any, index): Partial<Invoice> => {
        const invoice: Partial<Invoice> = { id: `${fileName}-${index}` };
        for (const appField in mapping) {
            const fileColumn = mapping[appField as keyof ColumnMapping];
            if (fileColumn && row[fileColumn] !== undefined && row[fileColumn] !== null) {
                (invoice as any)[appField] = row[fileColumn];
            }
        }
        return invoice;
    })
    .filter(inv => inv.documentNumber && inv.invoiceDate && inv.taxableValue !== undefined)
    .map(inv => ({
        ...inv,
        id: inv.id!,
        supplierGstin: String(inv.supplierGstin ?? '').trim(),
        supplierName: String(inv.supplierName ?? '').trim(),
        documentNumber: String(inv.documentNumber ?? '').trim(),
        invoiceDate: inv.invoiceDate!, // keep as raw value for our robust parser
        taxableValue: parseFloat(String(inv.taxableValue ?? '0').replace(/,/g, '')),
        igst: parseFloat(String(inv.igst ?? '0').replace(/,/g, '')),
        cgst: parseFloat(String(inv.cgst ?? '0').replace(/,/g, '')),
        sgst: parseFloat(String(inv.sgst ?? '0').replace(/,/g, '')),
        totalTax: parseFloat(String(inv.totalTax ?? '0').replace(/,/g, '')),
    })) as Invoice[];

    return mappedData;
};


export async function runReconciliation(
  prevState: any,
  formData: FormData
): Promise<SavedReconciliationRun | { error: string, results: ReconciliationResult[] }> {
  
  const internalFile = formData.get('internalFile') as File | null;
  const gstr2bFile = formData.get('gstr2bFile') as File | null;
  const internalFileMappingStr = formData.get('internalFileMapping') as string | null;
  const gstr2bFileMappingStr = formData.get('gstr2bFileMapping') as string | null;
  const apiKey = formData.get('apiKey') as string | null;
  const orgId = formData.get('orgId') as string | 'org_1';
  
  if (!internalFile || !gstr2bFile || !internalFileMappingStr || !gstr2bFileMappingStr) {
    return { 
        error: 'File Error',
        results: [{ status: 'All', internal: { id: 'error', supplierGstin: 'Error', documentNumber: 'File Error', invoiceDate: '', taxableValue: 0, totalTax: 0 }, alert: { priority: 'High', message: 'One or both data files were not provided.' } }]
    };
  }

  
  let internalData: Invoice[];
  let gstr2bData: Invoice[];
  
  try {
      const internalFileMapping = JSON.parse(internalFileMappingStr);
      const gstr2bFileMapping = JSON.parse(gstr2bFileMappingStr);
      
      const [internalBuffer, gstr2bBuffer] = await Promise.all([
          internalFile.arrayBuffer(),
          gstr2bFile.arrayBuffer()
      ]);

      internalData = parseFile(internalBuffer, internalFileMapping, internalFile.name);
      gstr2bData = parseFile(gstr2bBuffer, gstr2bFileMapping, gstr2bFile.name);

  } catch (error: any) {
      console.error("Error parsing data:", error);
      return { 
          error: 'Parsing Error',
          results: [{ status: 'All', internal: { id: 'error', supplierGstin: 'Error', documentNumber: 'Parsing', invoiceDate: '', taxableValue: 0, totalTax: 0 }, alert: { priority: 'High', message: 'Failed to parse the provided data: ' + error.message } }]
      };
  }


  const dateTolerance = Number(formData.get("dateToleranceDays")) || 0;
  const valueTolerancePercentage = Number(formData.get("valueTolerancePercentage")) || 0;

  const results: ReconciliationResult[] = [];
  const gstr2bMap = new Map<string, Invoice>();
  gstr2bData.forEach(inv => gstr2bMap.set(`${inv.supplierGstin}-${inv.documentNumber}`.trim().toLowerCase(), inv));

  let matchedCount = 0;
  let mismatchedCount = 0;
  let missingIn2BCount = 0;

  for (const internalInvoice of internalData) {
    const key = `${internalInvoice.supplierGstin}-${internalInvoice.documentNumber}`.trim().toLowerCase();
    const gstr2bInvoice = gstr2bMap.get(key);

    const result: ReconciliationResult = {
        status: 'All', // Will be overwritten
        internal: {
            ...internalInvoice,
            invoiceDate: parseDate(internalInvoice.invoiceDate) || String(internalInvoice.invoiceDate),
        }
    };

    if (gstr2bInvoice) {
      result.gstr2b = {
          ...gstr2bInvoice,
          invoiceDate: parseDate(gstr2bInvoice.invoiceDate) || String(gstr2bInvoice.invoiceDate),
          supplierName: gstr2bInvoice.supplierName || internalInvoice.supplierName,
      };
      const internalDateStr = result.internal?.invoiceDate;
      const gstr2bDateStr = result.gstr2b?.invoiceDate;
      
      const internalDate = internalDateStr ? parse(internalDateStr, 'yyyy-MM-dd', new Date()) : null;
      const gstr2bDate = gstr2bDateStr ? parse(gstr2bDateStr, 'yyyy-MM-dd', new Date()) : null;


      if (!internalDate || !gstr2bDate || !isValid(internalDate) || !isValid(gstr2bDate)) {
          result.status = 'Mismatched';
          result.alert = { priority: 'High', message: `One or both invoice dates are invalid. Internal: ${internalDateStr}, GSTR-2B: ${gstr2bDateStr}` };
          mismatchedCount++;
          results.push(result);
          gstr2bMap.delete(key);
          continue;
      }
      
      const dateDiff = Math.abs(differenceInDays(internalDate, gstr2bDate));
      const valueDiffPercentage = internalInvoice.taxableValue !== 0 
        ? Math.abs(internalInvoice.taxableValue - gstr2bInvoice.taxableValue) / internalInvoice.taxableValue * 100
        : (gstr2bInvoice.taxableValue > 0 ? 100 : 0);

      const isDateTolerated = dateDiff <= dateTolerance;
      const isValueTolerated = valueDiffPercentage <= valueTolerancePercentage;

      if (isDateTolerated && isValueTolerated) {
        result.status = 'Matched';
        matchedCount++;
      } else {
        result.status = 'Mismatched';
        mismatchedCount++;
        
        let message = 'Mismatch found: ';
        if(!isDateTolerated){
             message += `Date difference is ${dateDiff} days (tolerance is ${dateTolerance}). `;
        }
        if(!isValueTolerated){
            message += `Value difference is ${valueDiffPercentage.toFixed(2)}% (tolerance is ${valueTolerancePercentage}%).`;
        }
        result.alert = {
            priority: 'Medium',
            message: message,
        }
      }
      gstr2bMap.delete(key);
    } else {
      result.status = 'Missing in 2B';
      missingIn2BCount++;
      result.alert = { priority: 'High', message: 'Invoice missing in GSTR-2B. Potential ITC loss.' };
    }
    results.push(result);
  }

  const extraIn2BCount = gstr2bMap.size;
  gstr2bMap.forEach(gstr2bInvoice => {
    results.push({
      status: 'Extra in 2B',
      gstr2b: {
          ...gstr2bInvoice,
          invoiceDate: parseDate(gstr2bInvoice.invoiceDate) || String(gstr2bInvoice.invoiceDate),
      },
      alert: {
        priority: 'Low',
        message: 'This invoice is in GSTR-2B but not in your purchase records.'
      }
    });
  });

  const summary = {
    totalInvoices: internalData.length,
    matched: matchedCount,
    mismatched: mismatchedCount,
    missingIn2B: missingIn2BCount,
    extraIn2B: extraIn2BCount,
  };

  // Save the successful reconciliation run
  const savedRun = await saveReconciliationRun({
    orgId: orgId,
    summary,
    results,
  });

  return savedRun;
}

export async function getLatestReconciliation(orgId: string): Promise<ReconciliationOutput | null> {
  const runs = await getReconciliationRuns(orgId);
  if (runs.length > 0) {
    const latestRunId = runs[0].id;
    return getReconciliationReport(latestRunId);
  }
  return null;
}

export async function getAllReconciliationRuns(orgId: string) {
    return getReconciliationRuns(orgId);
}

export async function getReconciliationReport(runId: string): Promise<ReconciliationOutput> {
    const run = await getReconciliationRun(runId);
    if (!run) {
        return {
            summary: { totalInvoices: 0, matched: 0, mismatched: 0, missingIn2B: 0, extraIn2B: 0 },
            results: [{ status: 'All', internal: { id: 'error', supplierGstin: 'Error', documentNumber: 'Not Found', invoiceDate: '', taxableValue: 0, totalTax: 0 }, alert: { priority: 'High', message: `Report with ID ${runId} not found.` } }]
        };
    }
    return {
        summary: run.data.summary,
        results: run.data.results,
    };
}


export async function exportToCsv(runId: string) {
    const report = await getReconciliationReport(runId);
    if (!report || !report.results || report.results.some(r => r.internal?.documentNumber === 'Not Found')) {
        return { error: 'No data to export or report not found.' };
    }
    
    // Flatten the data for CSV export
    const dataToExport = report.results.map(item => ({
        'Status': item.status,
        'Invoice Number': item.internal?.documentNumber || item.gstr2b?.documentNumber,
        'Supplier Name': item.internal?.supplierName || item.gstr2b?.supplierName || '-',
        'Supplier GSTIN': item.internal?.supplierGstin || item.gstr2b?.supplierGstin,
        'Internal Invoice Date': item.internal?.invoiceDate || '-',
        'GSTR-2B Invoice Date': item.gstr2b?.invoiceDate || '-',
        'Internal Taxable Value': item.internal?.taxableValue?.toFixed(2) || '-',
        'GSTR-2B Taxable Value': item.gstr2b?.taxableValue?.toFixed(2) || '-',
        'Internal IGST': item.internal?.igst?.toFixed(2) || '-',
        'GSTR-2B IGST': item.gstr2b?.igst?.toFixed(2) || '-',
        'Internal CGST': item.internal?.cgst?.toFixed(2) || '-',
        'GSTR-2B CGST': item.gstr2b?.cgst?.toFixed(2) || '-',
        'Internal SGST': item.internal?.sgst?.toFixed(2) || '-',
        'GSTR-2B SGST': item.gstr2b?.sgst?.toFixed(2) || '-',
        'Internal Total Tax': item.internal?.totalTax?.toFixed(2) || '-',
        'GSTR-2B Total Tax': item.gstr2b?.totalTax?.toFixed(2) || '-',
        'Alert Priority': item.alert?.priority || 'None',
        'Alert Message': item.alert?.message || '-'
    }));

    const csv = Papa.unparse(dataToExport);

    return { csv };
}


// --- Smart Search ---
/*
import { smartSearch } from "@/ai/flows/smart-search-flow";
import type { SmartSearchOutput } from "@/lib/types";
import { subMonths, startOfMonth, endOfMonth, startOfYear, endOfYear, subDays, startOfDay, endOfDay } from "date-fns";

const applySmartSearchFilters = (results: ReconciliationResult[], filters: SmartSearchOutput): ReconciliationResult[] => {
    return results.filter(item => {
        const { status, amountGreaterThan, amountLessThan, startDate, endDate, supplierGstin, documentNumber, textSearch } = filters;
        
        if (status && status.length > 0 && !status.includes(item.status)) return false;
        
        const invoice = item.internal || item.gstr2b;
        if (!invoice) return false;

        if (amountGreaterThan && invoice.taxableValue <= amountGreaterThan) return false;
        if (amountLessThan && invoice.taxableValue >= amountLessThan) return false;
        if (supplierGstin && invoice.supplierGstin !== supplierGstin) return false;
        if (documentNumber && invoice.documentNumber !== documentNumber) return false;

        if (startDate) {
            const itemDate = invoice.invoiceDate ? parse(invoice.invoiceDate, 'yyyy-MM-dd', new Date()) : null;
            if (!itemDate || !isValid(itemDate) || itemDate < parse(startDate, 'yyyy-MM-dd', new Date())) return false;
        }

        if (endDate) {
            const itemDate = invoice.invoiceDate ? parse(invoice.invoiceDate, 'yyyy-MM-dd', new Date()) : null;
            if (!itemDate || !isValid(itemDate) || itemDate > parse(endDate, 'yyyy-MM-dd', new Date())) return false;
        }
        
        if (textSearch) {
            const lowerTextSearch = textSearch.toLowerCase();
            const matches = 
                invoice.supplierName?.toLowerCase().includes(lowerTextSearch) ||
                invoice.documentNumber?.toLowerCase().includes(lowerTextSearch) ||
                invoice.supplierGstin?.toLowerCase().includes(lowerTextSearch);
            if (!matches) return false;
        }

        return true;
    });
}


export async function getSmartSearchResults(query: string, apiKey: string, orgId: string): Promise<{ results?: ReconciliationResult[], error?: string }> {
    const latestRun = await getLatestReconciliation(orgId);
    if (!latestRun) {
        return { error: "No reconciliation report found. Please run a reconciliation first." };
    }
    
    try {
        const filters = await smartSearch({
            query: query,
            today: format(new Date(), 'yyyy-MM-dd'),
            apiKey: apiKey,
        });

        // If the AI returns no filters but there was a query, fall back to a simple text search
        if (Object.keys(filters).length === 0 && query) {
            filters.textSearch = query;
        }

        const filteredResults = applySmartSearchFilters(latestRun.results, filters);
        
        return { results: filteredResults };

    } catch (e: any) {
        console.error("Smart Search Error:", e);
        // Fallback to simple text search on error
        const fallbackFilters = { textSearch: query };
        const filteredResults = applySmartSearchFilters(latestRun.results, fallbackFilters);
        return { results: filteredResults };
    }
}
*/    

// --- AI Analysis ---
/*
import { reconciliationAlerts } from "@/ai/flows/reconciliation-alerts";

type MismatchData = {
    supplierGstin: string;
    documentNumber: string;
    internalTaxableValue: number;
    gst2bTaxableValue: number;
    internalInvoiceDate: string;
    gst2bInvoiceDate: string;
};

export async function runAiAnalysis(mismatches: MismatchData[], apiKey: string, orgId: string) {
    try {
        const response = await reconciliationAlerts({
            mismatches: mismatches,
            dateToleranceDays: 3, // These could be dynamic in the future
            valueTolerancePercentage: 0.1,
            orgId: orgId,
            apiKey,
        });
        return response;
    } catch (error: any) {
        console.error("AI Analysis Error:", error);
        throw new Error("Failed to get analysis from AI: " + error.message);
    }
}
*/
