

'use client';

import Link from "next/link"
import {
  Bell,
  CircleUser,
  Home,
  LineChart,
  Menu,
  Package,
  Package2,
  Search,
  ShoppingCart,
  Users,
  FileUp,
  FileText,
  Settings,
  LayoutGrid,
  LogOut,
  UserCircle,
  Building,
  ChevronsUpDown,
  Loader2
} from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Logo } from "@/components/logo"
import PaymentDialog from "@/components/payment-dialog"
import { useState, type KeyboardEvent } from "react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { OrganizationProvider, useOrganizations } from "@/context/organization-context";
import { useToast } from "@/hooks/use-toast"


// Mock user for demonstrating role-based UI
const mockCurrentUser = {
  id: 'user_super_admin',
  name: 'Super Admin',
  role: 'superadmin',
  orgId: 'org_admin_01'
};

const NAV_ITEMS = [
    { href: "/dashboard", icon: LayoutGrid, label: "Dashboard" },
    { href: "/dashboard/reconciliation", icon: FileUp, label: "Reconciliation" },
    { href: "/dashboard/reports", icon: FileText, label: "Reports" },
    { href: "/dashboard/organizations", icon: Building, label: "Organizations", requiredRole: "superadmin" },
    { href: "/dashboard/settings", icon: Settings, label: "Settings" },
];


function OrganizationSwitcher() {
    const [isOpen, setIsOpen] = useState(false);
    const { organizations, selectedOrganization, setSelectedOrganization } = useOrganizations();
    
    // A superadmin can see all organizations. A regular user would not see this switcher.
    if (mockCurrentUser.role !== 'superadmin') {
        return (
             <Button
                variant="outline"
                role="combobox"
                className="w-[200px] justify-start"
                disabled
            >
                <Building className="mr-2 h-4 w-4" />
                {selectedOrganization?.name}
            </Button>
        );
    }

    return (
        <Popover open={isOpen} onOpenChange={setIsOpen}>
            <PopoverTrigger asChild>
                <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={isOpen}
                    className="w-[200px] justify-between"
                >
                    <Building className="mr-2 h-4 w-4" />
                    {selectedOrganization?.name}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
            </PopoverTrigger>
            <PopoverContent className="w-[200px] p-0">
                 <div className="p-2">
                    {organizations.map((org) => (
                        <Button
                            key={org.id}
                            variant="ghost"
                            className="w-full justify-start"
                            onClick={() => {
                                setSelectedOrganization(org);
                                setIsOpen(false);
                            }}
                        >
                            <Building className="mr-2 h-4 w-4 shrink-0"/>
                            {org.name}
                        </Button>
                    ))}
                 </div>
            </PopoverContent>
        </Popover>
    );
}


function DashboardLayoutContent({
  children,
}: {
  children: React.ReactNode
}) {
    const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);

    const visibleNavItems = NAV_ITEMS.filter(item => !item.requiredRole || item.requiredRole === mockCurrentUser.role);

  return (
    <div className="grid min-h-screen w-full md:grid-cols-[220px_1fr] lg:grid-cols-[280px_1fr]">
      <div className="hidden border-r bg-card md:block">
        <div className="flex h-full max-h-screen flex-col gap-2">
          <div className="flex h-14 items-center border-b px-4 lg:h-[60px] lg:px-6">
            <Link href="/" className="flex items-center gap-2 font-semibold">
              <Logo className="h-8 w-8" />
              <span className="font-headline text-xl">GST Ace</span>
            </Link>
          </div>
          <div className="flex-1">
            <nav className="grid items-start px-2 text-sm font-medium lg:px-4">
              {visibleNavItems.map((item) => (
                <Link
                  key={item.label}
                  href={item.href}
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:text-primary"
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
          <div className="mt-auto p-4">
            <Card>
              <CardHeader className="p-2 pt-0 md:p-4">
                <CardTitle>Upgrade to Pro</CardTitle>
                <CardDescription>
                  Unlock all features and get unlimited access to our support team.
                </CardDescription>
              </CardHeader>
              <CardContent className="p-2 pt-0 md:p-4 md:pt-0">
                <Button size="sm" className="w-full" onClick={() => setIsPaymentDialogOpen(true)}>
                  Upgrade
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      <div className="flex flex-col">
        <header className="flex h-14 items-center gap-4 border-b bg-card px-4 lg:h-[60px] lg:px-6">
          <Sheet>
            <SheetTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="shrink-0 md:hidden"
              >
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle navigation menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="flex flex-col">
              <nav className="grid gap-2 text-lg font-medium">
                <Link
                  href="#"
                  className="flex items-center gap-2 text-lg font-semibold"
                >
                  <Logo className="h-8 w-8" />
                  <span className="sr-only">GST Ace</span>
                </Link>
                {visibleNavItems.map((item) => (
                    <Link
                    key={item.label}
                    href={item.href}
                    className="mx-[-0.65rem] flex items-center gap-4 rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground"
                    >
                    <item.icon className="h-5 w-5" />
                    {item.label}
                    </Link>
                ))}
              </nav>
              <div className="mt-auto">
                <Card>
                  <CardHeader>
                    <CardTitle>Upgrade to Pro</CardTitle>
                    <CardDescription>
                      Unlock all features and get unlimited access to our
                      support team.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button size="sm" className="w-full" onClick={() => setIsPaymentDialogOpen(true)}>
                      Upgrade
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </SheetContent>
          </Sheet>
          <div className="w-full flex-1 flex items-center gap-4">
              <OrganizationSwitcher />
              <div className="w-full" />
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="secondary" size="icon" className="rounded-full">
                <UserCircle className="h-5 w-5" />
                <span className="sr-only">Toggle user menu</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>{mockCurrentUser.name}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <Link href="/dashboard/settings" className="flex items-center gap-2">
                    <Settings className="h-4 w-4"/>
                    <span>Settings</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem>Support</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <Link href="/" className="flex items-center gap-2">
                    <LogOut className="h-4 w-4"/>
                    <span>Logout</span>
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </header>
        <main className="flex flex-1 flex-col gap-4 p-4 lg:gap-6 lg:p-6 bg-background">
          {children}
        </main>
      </div>
      <PaymentDialog isOpen={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen} />
    </div>
  )
}

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <OrganizationProvider>
      <DashboardLayoutContent>{children}</DashboardLayoutContent>
    </OrganizationProvider>
  )
}
