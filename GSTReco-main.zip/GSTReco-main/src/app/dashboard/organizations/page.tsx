

'use client'

import { useState, useMemo } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { MoreHorizontal, PlusCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useOrganizations } from "@/context/organization-context";
import type { Organization } from "@/context/organization-context";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";


export default function OrganizationsPage() {
  const { organizations, addOrganization, updateOrganization } = useOrganizations();
  const [searchTerm, setSearchTerm] = useState("");
  
  // State for Create Dialog
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newOrgName, setNewOrgName] = useState("");
  const [newOrgEmail, setNewOrgEmail] = useState("");

  // State for Edit Dialog
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingOrg, setEditingOrg] = useState<Organization | null>(null);
  const [editedOrgName, setEditedOrgName] = useState("");
  const [editedOrgEmail, setEditedOrgEmail] = useState("");
  const [editedOrgStatus, setEditedOrgStatus] = useState<Organization['status']>('Active');


  const filteredOrganizations = useMemo(() => {
    const term = searchTerm.toLowerCase();
    if (!term) return organizations;
    return organizations.filter(org => 
        org.name.toLowerCase().includes(term) ||
        org.adminEmail.toLowerCase().includes(term)
    );
  }, [organizations, searchTerm]);


  const handleCreateOrganization = () => {
    if (newOrgName && newOrgEmail) {
      addOrganization({
        name: newOrgName,
        adminEmail: newOrgEmail,
      });
      setIsCreateDialogOpen(false);
      setNewOrgName("");
      setNewOrgEmail("");
    }
  };

  const handleOpenEditDialog = (org: Organization) => {
    setEditingOrg(org);
    setEditedOrgName(org.name);
    setEditedOrgEmail(org.adminEmail);
    setEditedOrgStatus(org.status);
    setIsEditDialogOpen(true);
  };

  const handleUpdateOrganization = () => {
    if (editingOrg && editedOrgName && editedOrgEmail) {
        const updatedOrg = { ...editingOrg, name: editedOrgName, adminEmail: editedOrgEmail, status: editedOrgStatus };
        updateOrganization(updatedOrg);
      setIsEditDialogOpen(false);
      setEditingOrg(null);
    }
  };

  return (
    <>
      <div className="flex items-center justify-between">
        <h1 className="font-headline text-lg font-semibold md:text-2xl">
          Client Organization Management
        </h1>
        {/* Create Organization Dialog */}
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <PlusCircle className="mr-2 h-4 w-4" />
              Create New Organization
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Create New Organization</DialogTitle>
              <DialogDescription>
                Fill in the details below to add a new client organization.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="org-name-create" className="text-right">
                  Org Name
                </Label>
                <Input
                  id="org-name-create"
                  value={newOrgName}
                  onChange={(e) => setNewOrgName(e.target.value)}
                  className="col-span-3"
                  placeholder="Acme Inc."
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="admin-email-create" className="text-right">
                  Admin Email
                </Label>
                <Input
                  id="admin-email-create"
                  type="email"
                  value={newOrgEmail}
                  onChange={(e) => setNewOrgEmail(e.target.value)}
                  className="col-span-3"
                  placeholder="admin@example.com"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="submit" onClick={handleCreateOrganization}>Create Organization</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="mt-6">
        <CardHeader>
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                    <CardTitle>Manage Client Organizations</CardTitle>
                    <CardDescription>
                        Here is a list of all client organizations you manage.
                    </CardDescription>
                </div>
                <div className="relative">
                     <Input
                        placeholder="Filter by name or email..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="max-w-sm"
                    />
                </div>
            </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Organization Name</TableHead>
                <TableHead>Admin Email</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created At</TableHead>
                <TableHead>
                  <span className="sr-only">Actions</span>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredOrganizations.map((org) => (
                <TableRow key={org.id}>
                  <TableCell className="font-medium">{org.name}</TableCell>
                  <TableCell>{org.adminEmail}</TableCell>
                  <TableCell>
                    <Badge variant={org.status === 'Active' ? 'default' : 'secondary'}>
                      {org.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{org.createdAt}</TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button aria-haspopup="true" size="icon" variant="ghost">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Toggle menu</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem onSelect={() => handleOpenEditDialog(org)}>
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem>View Details</DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive">
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      {/* Edit Organization Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Edit Organization</DialogTitle>
              <DialogDescription>
                Update the details for {editingOrg?.name}.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="org-name-edit" className="text-right">
                  Org Name
                </Label>
                <Input
                  id="org-name-edit"
                  value={editedOrgName}
                  onChange={(e) => setEditedOrgName(e.target.value)}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="admin-email-edit" className="text-right">
                  Admin Email
                </Label>
                <Input
                  id="admin-email-edit"
                  type="email"
                  value={editedOrgEmail}
                  onChange={(e) => setEditedOrgEmail(e.target.value)}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="status-edit" className="text-right">
                  Status
                </Label>
                <Select value={editedOrgStatus} onValueChange={(value) => setEditedOrgStatus(value as Organization['status'])}>
                    <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select a status" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="Active">Active</SelectItem>
                        <SelectItem value="Inactive">Inactive</SelectItem>
                    </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>Cancel</Button>
              <Button type="submit" onClick={handleUpdateOrganization}>Save Changes</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
    </>
  )
}
