

'use client';

import {
  FileText,
  CheckCircle2,
  AlertTriangle,
  Archive,
  PlusCircle,
} from "lucide-react";
import SummaryCard from "@/components/summary-card";
import ReportTable from "@/components/report-table";
import { getLatestReconciliation } from "@/app/actions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { SearchProvider } from "@/context/search-context";
import { useEffect, useState } from "react";
import { useOrganizations } from "@/context/organization-context";
import type { ReconciliationOutput } from "@/lib/types";

export default function DashboardPage() {
  const { selectedOrganization } = useOrganizations();
  const [latestRun, setLatestRun] = useState<ReconciliationOutput | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (selectedOrganization) {
      setIsLoading(true);
      getLatestReconciliation(selectedOrganization.id)
        .then(data => {
          setLatestRun(data);
          setIsLoading(false);
        });
    } else {
      setLatestRun(null);
      setIsLoading(false);
    }
  }, [selectedOrganization]);


  const hasResults = latestRun && latestRun.results.length > 0;

  if (isLoading) {
    return (
      <div className="flex flex-1 items-center justify-center rounded-lg border border-dashed shadow-sm">
        <p>Loading dashboard...</p>
      </div>
    );
  }

  return (
    <SearchProvider>
      <div className="flex items-center">
        <h1 className="font-headline text-lg font-semibold md:text-2xl">
          Dashboard for <span className="text-primary">{selectedOrganization?.name}</span>
        </h1>
      </div>
      {hasResults ? (
        <>
          <div className="grid gap-4 md:grid-cols-2 md:gap-8 lg:grid-cols-5">
            <SummaryCard
              title="Total Invoices"
              value={latestRun.summary.totalInvoices.toString()}
              icon={FileText}
            />
            <SummaryCard
              title="Matched"
              value={latestRun.summary.matched.toString()}
              icon={CheckCircle2}
              valueClassName="text-green-600"
            />
            <SummaryCard
              title="Mismatched"
              value={latestRun.summary.mismatched.toString()}
              icon={AlertTriangle}
              valueClassName="text-orange-600"
            />
            <SummaryCard
              title="Missing in 2B"
              value={latestRun.summary.missingIn2B.toString()}
              icon={Archive}
              valueClassName="text-red-600"
            />
            <SummaryCard
              title="Extra in 2B"
              value={latestRun.summary.extraIn2B.toString()}
              icon={PlusCircle}
              valueClassName="text-blue-600"
            />
          </div>
          <div className="flex flex-col">
            <h2 className="font-headline text-lg font-semibold md:text-xl mb-4">
              Latest Reconciliation Overview
            </h2>
            <ReportTable initialData={latestRun.results} />
          </div>
        </>
      ) : (
        <div className="flex flex-1 items-center justify-center rounded-lg border border-dashed shadow-sm">
          <div className="flex flex-col items-center gap-4 text-center">
             <FileText className="h-16 w-16 text-muted-foreground" />
            <h3 className="text-2xl font-bold tracking-tight">
              No reconciliation run yet for {selectedOrganization?.name}
            </h3>
            <p className="text-sm text-muted-foreground">
              Get started by running your first reconciliation for this organization.
            </p>
            <Link href="/dashboard/reconciliation">
              <Button className="mt-4">Run New Reconciliation</Button>
            </Link>
          </div>
        </div>
      )}
    </SearchProvider>
  );
}
