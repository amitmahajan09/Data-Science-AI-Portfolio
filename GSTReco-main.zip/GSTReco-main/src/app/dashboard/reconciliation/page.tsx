import ReconciliationForm from "@/components/reconciliation-form";

export default function ReconciliationPage() {
  return (
    <>
      <div className="flex items-center">
        <h1 className="font-headline text-lg font-semibold md:text-2xl">
          New Reconciliation
        </h1>
      </div>
      <div className="flex-1 rounded-lg border-2 border-dashed shadow-sm p-8 flex items-center justify-center">
        <ReconciliationForm />
      </div>
    </>
  );
}
