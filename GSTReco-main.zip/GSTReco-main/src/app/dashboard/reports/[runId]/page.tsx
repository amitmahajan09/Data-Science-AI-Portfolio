
'use client';

import { useEffect, useState, use } from 'react';
import { getReconciliationReport, exportToCsv } from "@/app/actions";
import ReportTable from "@/components/report-table";
import { Button } from "@/components/ui/button";
import { Download, Loader2, AlertTriangle } from "lucide-react";
import type { ReconciliationOutput } from '@/lib/types';
import * as XLSX from 'xlsx';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { SearchProvider } from '@/context/search-context';

export default function ReportDetailPage({ params }: { params: { runId: string } }) {
    const { runId } = use(params);
    const [reportData, setReportData] = useState<ReconciliationOutput | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isExporting, setIsExporting] = useState(false);
    const { toast } = useToast();

    useEffect(() => {
        if (runId) {
            setIsLoading(true);
            getReconciliationReport(runId).then(data => {
                setReportData(data);
                setIsLoading(false);
            });
        }
    }, [runId]);
    
    const handleExport = async (format: 'csv' | 'xlsx') => {
        setIsExporting(true);
        try {
            const { csv, error } = await exportToCsv(runId);

            if (error || !csv) {
                toast({ title: 'Export Failed', description: error || 'Could not generate file.', variant: 'destructive' });
                return;
            }

            const fileName = `reconciliation-report-${runId.split('-')[1]}`;

            if (format === 'csv') {
                const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
                const link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.setAttribute('download', `${fileName}.csv`);
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            } else { // xlsx
                const worksheet = XLSX.utils.json_to_sheet(XLSX.utils.sheet_to_json(XLSX.read(csv, {type: 'string'}).Sheets.Sheet1));
                const workbook = XLSX.utils.book_new();
                XLSX.utils.book_append_sheet(workbook, worksheet, 'Report');
                XLSX.writeFile(workbook, `${fileName}.xlsx`);
            }

        } catch (e: any) {
            toast({ title: 'Export Failed', description: e.message, variant: 'destructive' });
        } finally {
            setIsExporting(false);
        }
    };


    if (isLoading) {
        return (
            <div className="flex items-center justify-center h-full">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
        );
    }
    
    const isReportNotFound = !reportData || reportData.results.length === 0 || reportData.results.some(r => r.internal?.documentNumber === 'Not Found');

    if (isReportNotFound) {
        return (
            <Card className="text-center">
                <CardHeader>
                    <div className="mx-auto bg-destructive/10 p-3 rounded-full">
                        <AlertTriangle className="h-8 w-8 text-destructive" />
                    </div>
                    <CardTitle className="mt-4">Report Not Found</CardTitle>
                    <CardDescription>
                        The report with ID <span className="font-mono text-destructive">{runId}</span> could not be found. It may have expired or never existed.
                    </CardDescription>
                </CardHeader>
            </Card>
        );
    }


    return (
        <SearchProvider>
            <div className="flex items-center justify-between">
                <h1 className="font-headline text-lg font-semibold md:text-2xl">
                    Detailed Report for Run <span className="text-primary font-mono">{runId.split('-')[1]}</span>
                </h1>
                <div className="flex gap-2">
                     <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button disabled={isExporting}>
                                {isExporting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Download className="mr-2 h-4 w-4" />}
                                <span>Export</span>
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                             <DropdownMenuItem onSelect={() => handleExport('csv')}>
                                Export to CSV
                            </DropdownMenuItem>
                            <DropdownMenuItem onSelect={() => handleExport('xlsx')}>
                                Export to XLSX
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                </div>
            </div>
            <div className="flex flex-col mt-6">
                <ReportTable initialData={reportData.results} />
            </div>
        </SearchProvider>
    );
}
