
'use client';

import { useEffect, useState } from 'react';
import Link from "next/link";
import { getAllReconciliationRuns } from "@/app/actions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Eye, FileText, Loader2 } from "lucide-react";
import { format } from "date-fns";
import ReportActions from "@/components/report-actions";
import { useOrganizations } from '@/context/organization-context';
import type { SavedReconciliationRun } from '@/lib/types';

export default function ReportsListPage() {
    const { selectedOrganization } = useOrganizations();
    const [runs, setRuns] = useState<SavedReconciliationRun[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        if (selectedOrganization) {
            setIsLoading(true);
            getAllReconciliationRuns(selectedOrganization.id)
                .then(data => {
                    setRuns(data);
                    setIsLoading(false);
                });
        } else {
            setRuns([]);
            setIsLoading(false);
        }
    }, [selectedOrganization]);

    return (
        <>
            <div className="flex items-center justify-between">
                <h1 className="font-headline text-lg font-semibold md:text-2xl">
                    Reconciliation Reports for <span className="text-primary">{selectedOrganization?.name}</span>
                </h1>
            </div>

            {isLoading ? (
                 <div className="flex flex-1 items-center justify-center rounded-lg border border-dashed shadow-sm mt-6">
                    <Loader2 className="h-16 w-16 animate-spin text-primary" />
                </div>
            ) : runs.length > 0 ? (
                <Card className="mt-6">
                    <CardHeader>
                        <CardTitle>Run History</CardTitle>
                        <CardDescription>
                            Here is a list of all the reconciliation reports you have generated for this organization.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Run Date</TableHead>
                                    <TableHead>Run By</TableHead>
                                    <TableHead>Total Invoices</TableHead>
                                    <TableHead>Matched</TableHead>
                                    <TableHead>Mismatched</TableHead>
                                    <TableHead>Missing in 2B</TableHead>
                                    <TableHead className="text-right">Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {runs.map((run) => (
                                    <TableRow key={run.id}>
                                        <TableCell>{format(new Date(run.runDate), "PPP p")}</TableCell>
                                        <TableCell>{run.user}</TableCell>
                                        <TableCell>{run.data.summary.totalInvoices}</TableCell>
                                        <TableCell>
                                            <Badge variant="outline" className="border-green-500 text-green-700">{run.data.summary.matched}</Badge>
                                        </TableCell>
                                        <TableCell>
                                            <Badge variant="outline" className="border-orange-500 text-orange-700">{run.data.summary.mismatched}</Badge>
                                        </TableCell>
                                        <TableCell>
                                            <Badge variant="destructive">{run.data.summary.missingIn2B}</Badge>
                                        </TableCell>
                                        <TableCell className="text-right">
                                            <ReportActions runId={run.id} />
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            ) : (
                <div className="flex flex-1 items-center justify-center rounded-lg border border-dashed shadow-sm mt-6">
                    <div className="flex flex-col items-center gap-4 text-center">
                        <FileText className="h-16 w-16 text-muted-foreground" />
                        <h3 className="text-2xl font-bold tracking-tight">
                            No Reports Found
                        </h3>
                        <p className="text-sm text-muted-foreground">
                            Run a new reconciliation to generate your first report for {selectedOrganization?.name}.
                        </p>
                         <Link href="/dashboard/reconciliation">
                            <Button className="mt-4">Run New Reconciliation</Button>
                        </Link>
                    </div>
                </div>
            )}
        </>
    );
}
