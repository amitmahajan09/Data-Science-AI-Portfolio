

'use client';

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, CreditCard, Puzzle, KeyRound, Trash2, ExternalLink } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import PaymentDialog from "@/components/payment-dialog";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";

const API_KEY_STORAGE_KEY = 'gemini-api-key';

export default function SettingsPage() {
  const { toast } = useToast();
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [isInviteDialogOpen, setIsInviteDialogOpen] = useState(false);
  const [apiKey, setApiKey] = useState('');

  useEffect(() => {
    // Load the key from local storage on component mount
    const savedKey = localStorage.getItem(API_KEY_STORAGE_KEY);
    if (savedKey) {
      setApiKey(savedKey);
    }
  }, []);

  const handleSendInvite = () => {
    setIsInviteDialogOpen(false);
    toast({
        title: "Invitation Sent!",
        description: "The user has been invited to join your organization."
    });
  }
  
  const handleClearMapping = (mappingKey: 'internal' | 'gstr2b') => {
      try {
          localStorage.removeItem(`gst-ace-mapping-${mappingKey}`);
          toast({
              title: "Mapping Cleared!",
              description: `The saved column mapping for ${mappingKey === 'internal' ? 'Internal' : 'GSTR-2B'} data has been cleared.`,
          });
      } catch (error) {
          console.error("Failed to clear mapping from localStorage", error);
          toast({
              title: "Error",
              description: "Could not clear the mapping. Your browser might be blocking localStorage.",
              variant: "destructive"
          });
      }
  };

  const handleSaveApiKey = () => {
    if (apiKey) {
      localStorage.setItem(API_KEY_STORAGE_KEY, apiKey);
      toast({
        title: "API Key Saved",
        description: "Your Gemini API key has been saved to your browser's local storage.",
      });
    } else {
      localStorage.removeItem(API_KEY_STORAGE_KEY);
       toast({
        title: "API Key Removed",
        description: "Your Gemini API key has been removed from local storage.",
        variant: 'destructive'
      });
    }
  }


  return (
    <>
      <div className="flex flex-1 flex-col">
        <div className="flex items-center">
          <h1 className="font-headline text-lg font-semibold md:text-2xl">
            Settings
          </h1>
        </div>
        <div className="grid gap-6 pt-6">
          <Card>
              <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                  <KeyRound className="h-5 w-5" />
                  <span>AI Configuration</span>
                   <Badge variant="secondary">Coming Soon</Badge>
                  </CardTitle>
                  <CardDescription>
                    Manage your Google AI (Gemini) API key here. This key is required for AI features like Smart Search and automated discrepancy analysis. Get your key from Google AI Studio.
                  </CardDescription>
              </CardHeader>
              <CardContent>
                  <div className="space-y-2">
                      <Label htmlFor="gemini-api-key" className="text-muted-foreground">Gemini API Key</Label>
                      <div className="flex items-center gap-2">
                         <Input 
                            id="gemini-api-key" 
                            name="apiKey" 
                            type="password" 
                            placeholder="Enter your Gemini API Key" 
                            value={apiKey}
                            onChange={(e) => setApiKey(e.target.value)}
                            disabled
                         />
                         <Button onClick={handleSaveApiKey} disabled>Save Key</Button>
                      </div>
                      <p className="text-xs text-muted-foreground pt-1">
                        Your API key will be stored securely in your browser's local storage.
                         <Link href="https://aistudio.google.com/app/apikey" target="_blank" className="underline ml-1">
                            Get API Key <ExternalLink className="inline h-3 w-3" />
                         </Link>
                      </p>
                  </div>
              </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                <span>User Management</span>
              </CardTitle>
              <CardDescription>
                Manage your organization's users and their roles.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">Invite and manage users in your organization.</p>
            </CardContent>
            <CardFooter className="border-t px-6 py-4">
              <Dialog open={isInviteDialogOpen} onOpenChange={setIsInviteDialogOpen}>
                <DialogTrigger asChild>
                  <Button>Invite User</Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[425px]">
                  <DialogHeader>
                    <DialogTitle>Invite User</DialogTitle>
                    <DialogDescription>
                      Enter the email address and select a role for the new user.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="email" className="text-right">
                        Email
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="user@example.com"
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="role" className="text-right">
                        Role
                      </Label>
                      <Select>
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select a role" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="admin">Admin</SelectItem>
                          <SelectItem value="analyst">Analyst</SelectItem>
                          <SelectItem value="viewer">Viewer</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsInviteDialogOpen(false)}>Cancel</Button>
                    <Button type="submit" onClick={handleSendInvite}>Send Invite</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                <span>Subscription</span>
              </CardTitle>
              <CardDescription>
                Manage your billing information and subscription plan.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <p>You are currently on the <span className="font-semibold text-primary">Trial Plan</span>.</p>
                <p className="text-sm text-muted-foreground">Your trial ends in 12 days.</p>
              </div>
            </CardContent>
            <CardFooter className="border-t px-6 py-4">
              <Button onClick={() => setIsPaymentDialogOpen(true)}>Upgrade to Pro</Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Puzzle className="h-5 w-5" />
                <span>Column Mapping</span>
              </CardTitle>
              <CardDescription>
                Clear your saved column mappings here. You will be prompted to re-map on your next upload.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">If your file structure changes, clear the saved configuration to create a new one.</p>
            </CardContent>
            <CardFooter className="border-t px-6 py-4 flex gap-4">
               <AlertDialog>
                    <AlertDialogTrigger asChild>
                        <Button variant="outline"><Trash2 className="mr-2 h-4 w-4" /> Clear Internal Data Mapping</Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                        <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                        <AlertDialogDescription>
                            This will remove the saved column mapping for your Internal Purchase Data files. You will need to re-map the columns on your next upload.
                        </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleClearMapping('internal')}>Continue</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
                 <AlertDialog>
                    <AlertDialogTrigger asChild>
                        <Button variant="outline"><Trash2 className="mr-2 h-4 w-4" /> Clear GSTR-2B Mapping</Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                        <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                        <AlertDialogDescription>
                            This will remove the saved column mapping for your GSTR-2B files. You will need to re-map the columns on your next upload.
                        </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleClearMapping('gstr2b')}>Continue</AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            </CardFooter>
          </Card>
        </div>
      </div>
      <PaymentDialog isOpen={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen} />
    </>
  );
}
