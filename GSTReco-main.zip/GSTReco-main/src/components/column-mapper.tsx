'use client';

import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { requiredFields } from '@/lib/data';
import type { ColumnMapping } from '@/lib/types';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { AlertTriangle } from 'lucide-react';

interface ColumnMapperProps {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  onSave: (mapping: ColumnMapping) => void;
  fileColumns: string[];
  fileName: string;
}

export default function ColumnMapper({ isOpen, onOpenChange, onSave, fileColumns, fileName }: ColumnMapperProps) {
  const [mapping, setMapping] = useState<ColumnMapping>({});

  useEffect(() => {
    const initialMapping: ColumnMapping = {};
    const lowerCaseFileColumns = fileColumns.map(c => c.toLowerCase());

    requiredFields.forEach(field => {
        const fieldVariations = [field.id, field.label, ...field.commonVariations].map(v => v.toLowerCase());
        
        // Find the first matching column from the uploaded file for the current field
        const matchedColumn = fileColumns.find(fileCol => {
            const lowerFileCol = fileCol.toLowerCase();
            return fieldVariations.includes(lowerFileCol);
        });

        if (matchedColumn) {
            initialMapping[field.id as keyof ColumnMapping] = matchedColumn;
        }
    });
    setMapping(initialMapping);
  }, [fileColumns]);

  const handleSave = () => {
    onSave(mapping);
    onOpenChange(false);
  }

  const handleSelectChange = (fieldId: string, value: string) => {
    setMapping(prev => ({...prev, [fieldId]: value}));
  }

  const isMappingComplete = requiredFields.every(field => mapping[field.id as keyof ColumnMapping]);


  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[625px]">
        <DialogHeader>
          <DialogTitle>Map Columns for: <span className="font-semibold text-primary">{fileName}</span></DialogTitle>
          <DialogDescription>
            Match your file's columns to the required application fields. We've made some guesses for you.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4 max-h-[60vh] overflow-y-auto pr-2">
          {requiredFields.map(field => (
            <div key={field.id} className="grid grid-cols-3 items-center gap-4">
              <Label htmlFor={field.id} className="text-right">
                {field.label}
              </Label>
              <div className="col-span-2">
                <Select onValueChange={(value) => handleSelectChange(field.id, value)} value={mapping[field.id as keyof ColumnMapping] || ''}>
                  <SelectTrigger id={field.id}>
                    <SelectValue placeholder="Select a column from your file" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="null" disabled>Select a column</SelectItem>
                    {fileColumns.map((column, index) => (
                      <SelectItem key={`${column}-${index}`} value={column}>
                        {column}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          ))}
        </div>
        {!isMappingComplete && (
            <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Mapping Incomplete</AlertTitle>
                <AlertDescription>
                    Please map all the required fields to continue.
                </AlertDescription>
            </Alert>
        )}
        <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Mapping is important!</AlertTitle>
            <AlertDescription>
                Correctly mapping these columns is crucial for the reconciliation to work. This mapping will be saved for future uploads with the same file structure.
            </AlertDescription>
        </Alert>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button type="button" onClick={handleSave} disabled={!isMappingComplete}>Save Mapping</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
