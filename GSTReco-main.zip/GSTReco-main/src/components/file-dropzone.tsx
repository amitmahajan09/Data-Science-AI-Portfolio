'use client';

import { useState, useRef, type DragEvent } from 'react';
import { UploadCloud, File as FileIcon, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';

interface FileDropzoneProps {
  onFileSelect: (file: File) => void;
  file: File | null;
  setFile: (file: File | null) => void;
  title: string;
  description: string;
  name: string; // Add name attribute
}

export default function FileDropzone({
  onFileSelect,
  file,
  setFile,
  title,
  description,
  name,
}: FileDropzoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragEnter = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleFileClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFileSelect(e.target.files[0]);
    }
  };
  
  const handleRemoveFile = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation(); // prevent card click event
    setFile(null);
    // Also clear the file input so the same file can be re-selected
    if (fileInputRef.current) {
        fileInputRef.current.value = "";
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        onClick={handleFileClick}
        className={cn(
          "flex flex-col items-center justify-center text-center p-10 border-2 border-dashed rounded-lg cursor-pointer transition-colors",
          isDragging ? "border-primary bg-accent" : "border-muted"
        )}
      >
        <input
          type="file"
          ref={fileInputRef}
          name={name}
          onChange={handleFileChange}
          className="hidden"
          accept=".csv, .xlsx, .xls, text/csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
        />
        {file ? (
            <div className="flex flex-col items-center gap-2">
                <div className="flex items-center gap-4 p-4 bg-background rounded-lg shadow w-full">
                    <FileIcon className="h-8 w-8 text-primary" />
                    <span className="text-sm font-medium truncate">{file.name}</span>
                    <Button variant="ghost" size="icon" onClick={handleRemoveFile} className="ml-auto">
                        <X className="h-4 w-4" />
                    </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-2">Click or drag to replace the file</p>
            </div>
        ) : (
          <>
            <UploadCloud className="h-12 w-12 text-muted-foreground" />
            <p className="mt-4 text-sm text-muted-foreground">
              Drag & drop or click to upload
            </p>
          </>
        )}
      </CardContent>
    </Card>
  );
}
