

'use client';

import { useState, useActionState, useRef, useEffect } from 'react';
import { runReconciliation } from '@/app/actions';
import type { ColumnMapping, SavedReconciliationRun } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, PartyPopper, Settings, Info } from 'lucide-react';
import ColumnMapper from './column-mapper';
import { useToast } from '@/hooks/use-toast';
import FileDropzone from './file-dropzone';
import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import Link from 'next/link';
import { Alert, AlertTitle, AlertDescription } from './ui/alert';
import { useOrganizations } from '@/context/organization-context';

const initialState: SavedReconciliationRun | { error: string, results: any[] } | null = null;
const MAPPING_STORAGE_PREFIX = 'gst-ace-mapping-';
const API_KEY_STORAGE_KEY = 'gemini-api-key';


export default function ReconciliationForm() {
    const [state, formAction, isPending] = useActionState(runReconciliation, initialState);
    const [mapperState, setMapperState] = useState<{isOpen: boolean; file: File | null; fileType: 'internal' | 'gstr2b' | null; columns: string[]}>({ isOpen: false, file: null, fileType: null, columns: [] });
    const { toast } = useToast();
    const { selectedOrganization } = useOrganizations();
    
    const [internalFile, setInternalFile] = useState<File | null>(null);
    const [gstr2bFile, setGstr2bFile] = useState<File | null>(null);
    
    const [internalFileMapping, setInternalFileMapping] = useState<ColumnMapping | null>(null);
    const [gstr2bFileMapping, setGstr2bFileMapping] = useState<ColumnMapping | null>(null);

    const formRef = useRef<HTMLFormElement>(null);
    
    // Load mappings from localStorage on initial render
    useEffect(() => {
        try {
            const savedInternalMapping = localStorage.getItem(`${MAPPING_STORAGE_PREFIX}internal`);
            const savedGstr2bMapping = localStorage.getItem(`${MAPPING_STORAGE_PREFIX}gstr2b`);
            if (savedInternalMapping) {
                setInternalFileMapping(JSON.parse(savedInternalMapping));
            }
            if (savedGstr2bMapping) {
                setGstr2bFileMapping(JSON.parse(savedGstr2bMapping));
            }
        } catch (error) {
            console.error("Failed to load mappings from localStorage", error);
        }
    }, []);

    useEffect(() => {
        if (state?.error) {
             toast({
                title: "Reconciliation Error",
                description: (state.results && state.results.length > 0) ? state.results[0].alert?.message : "An unknown error occurred.",
                variant: "destructive"
            });
        }
    }, [state, toast]);


    const handleMappingSave = (mapping: ColumnMapping) => {
        const fileType = mapperState.fileType;
        if (fileType) {
            if (fileType === 'internal') {
                setInternalFileMapping(mapping);
            } else {
                setGstr2bFileMapping(mapping);
            }
            // Save to localStorage
            try {
                localStorage.setItem(`${MAPPING_STORAGE_PREFIX}${fileType}`, JSON.stringify(mapping));
            } catch (error) {
                 console.error("Failed to save mapping to localStorage", error);
                 toast({
                    title: "Could not save mapping",
                    description: "Your browser might be blocking localStorage.",
                    variant: "destructive"
                });
            }
        }
        
        setMapperState({ isOpen: false, file: null, fileType: null, columns: [] });
        
        toast({
            title: "Mapping Saved",
            description: `Column mapping for ${mapperState.file?.name} has been saved.`,
        });
    }

    const getHeaders = (file: File, onComplete: (headers: string[]) => void, onError: (message: string) => void) => {
        const reader = new FileReader();
        const isExcel = file.name.endsWith('.xlsx') || file.name.endsWith('.xls');

        reader.onload = (e) => {
            try {
                const data = e.target?.result;
                let fileHeaders: string[];
                if (isExcel) {
                    const workbook = XLSX.read(data, { type: 'binary', sheetRows: 1 });
                    const sheetName = workbook.SheetNames[0];
                    const worksheet = workbook.Sheets[sheetName];
                    const jsonData = XLSX.utils.sheet_to_json<string[]>(worksheet, { header: 1 });
                    fileHeaders = (jsonData[0] || []).map(h => String(h || '').trim()).filter(Boolean);
                } else { // CSV
                    const text = data as string;
                    // PapaParse can handle header detection from the first line.
                    const papaResult = Papa.parse(text, { 
                        preview: 1, 
                        skipEmptyLines: true, 
                        header: false, // Parse first row as data to get headers
                    });

                    // The first row of data is our headers
                    fileHeaders = (papaResult.data[0] as string[] || []).map(h => h.trim()).filter(Boolean);
                }

                if (fileHeaders.length === 0) {
                    onError("Could not find any columns/headers in the file.");
                    return;
                }
                onComplete(fileHeaders);

            } catch (error: any) {
                onError("Failed to read file headers. The file might be corrupt or in an unsupported format.");
            }
        };
        
        reader.onerror = () => {
            onError("Failed to read the file.");
        };

        if (isExcel) {
            reader.readAsBinaryString(file);
        } else {
            // For CSV, explicitly use UTF-8
            reader.readAsText(file, 'UTF-8');
        }
    };


    const processFile = (file: File, fileType: 'internal' | 'gstr2b') => {
        const savedMapping = fileType === 'internal' ? internalFileMapping : gstr2bFileMapping;
        const fileSetter = fileType === 'internal' ? setInternalFile : setGstr2bFile;
        fileSetter(file);

        if (savedMapping) {
            toast({
                title: "Using Saved Mapping",
                description: `Found a saved column mapping for ${fileType} files.`,
            });
            return;
        }

        // No mapping found, open the mapper UI
        getHeaders(
            file,
            (headers) => {
                 setMapperState({
                    isOpen: true,
                    file: file,
                    fileType: fileType,
                    columns: headers,
                });
            },
            (errorMessage) => {
                toast({ title: "Error Reading File", description: errorMessage, variant: 'destructive' });
                fileSetter(null);
            }
        );
    };
    
    const handleFormAction = (formData: FormData) => {
        if (!internalFile || !gstr2bFile || !internalFileMapping || !gstr2bFileMapping) {
            toast({
                title: "Missing Information",
                description: "Please upload and map both files before starting reconciliation.",
                variant: "destructive"
            });
            return;
        }

        const apiKey = localStorage.getItem(API_KEY_STORAGE_KEY);
        // Temporarily disable API key check
        // if (!apiKey) {
        //    toast({
        //        title: "API Key Missing",
        //        description: "Please save your Gemini API key in the Settings page before running a reconciliation.",
        //        variant: "destructive"
        //    });
        //    return;
        // }
        
        formData.append('internalFile', internalFile);
        formData.append('gstr2bFile', gstr2bFile);
        formData.append('internalFileMapping', JSON.stringify(internalFileMapping));
        formData.append('gstr2bFileMapping', JSON.stringify(gstr2bFileMapping));
        formData.append('apiKey', apiKey || '');
        formData.append('orgId', selectedOrganization?.id || 'org_1');
        
        formAction(formData);
    }


    const isSuccessfulRun = (s: typeof state): s is SavedReconciliationRun => {
        return s !== null && 'id' in s && 'data' in s;
    }


    return (
        <div className="w-full max-w-4xl mx-auto">
            {!isSuccessfulRun(state) ? (
                <form ref={formRef} action={handleFormAction} className="space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <FileDropzone 
                            title="Internal Purchase Data"
                            description="Upload your internal purchase register."
                            file={internalFile}
                            setFile={setInternalFile}
                            onFileSelect={(file) => processFile(file, 'internal')}
                            name="internalFileDisplay"
                        />
                        <FileDropzone 
                            title="GSTR-2B Data"
                            description="Upload the file from GSTN portal."
                            file={gstr2bFile}
                            setFile={setGstr2bFile}
                            onFileSelect={(file) => processFile(file, 'gstr2b')}
                            name="gstr2bFileDisplay"
                        />
                    </div>
                    
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        <Card>
                            <CardHeader>
                                <CardTitle>Tolerance Settings</CardTitle>
                                <CardDescription>Configure tolerances for matching invoices.</CardDescription>
                            </CardHeader>
                            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor="dateToleranceDays">Date Tolerance (in days)</Label>
                                    <Input id="dateToleranceDays" name="dateToleranceDays" type="number" defaultValue="3" />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="valueTolerancePercentage">Value Tolerance (in %)</Label>
                                    <Input id="valueTolerancePercentage" name="valueTolerancePercentage" type="number" step="0.1" defaultValue="0.1" />
                                </div>
                            </CardContent>
                        </Card>
                         <Alert>
                            <Info className="h-4 w-4" />
                            <AlertTitle>Saved Mappings & API Key</AlertTitle>
                            <AlertDescription>
                                Column mappings and your API key are saved in your browser. To change them, go to the settings page.
                            </AlertDescription>
                            <div className="mt-3">
                                <Link href="/dashboard/settings">
                                    <Button variant="outline" size="sm">
                                        <Settings className="mr-2 h-4 w-4"/>
                                        Go to Settings
                                    </Button>
                                </Link>
                            </div>
                        </Alert>
                    </div>

                    
                     <Button type="submit" disabled={isPending} className="w-full">
                        {isPending ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Reconciling...
                            </>
                        ) : (
                            'Start Reconciliation'
                        )}
                    </Button>
                    
                    {mapperState.isOpen && mapperState.file && (
                        <ColumnMapper 
                            isOpen={mapperState.isOpen} 
                            onOpenChange={(isOpen) => setMapperState(prev => ({...prev, isOpen}))} 
                            onSave={handleMappingSave} 
                            fileColumns={mapperState.columns}
                            fileName={mapperState.file.name}
                        />
                    )}
                </form>
            ) : (
                <div className="space-y-6">
                    <div className="text-center p-8 bg-green-50 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-800 flex flex-col items-center">
                        <PartyPopper className="h-12 w-12 text-green-600 mx-auto mb-4" />
                        <h2 className="font-headline text-2xl font-semibold text-green-700 dark:text-green-400">Reconciliation Complete!</h2>
                        <p className="text-muted-foreground mt-2 mb-6">Your report has been successfully generated and saved.</p>
                        <Link href={`/dashboard/reports/${state.id}`}>
                            <Button size="lg">
                                <PartyPopper className="mr-2 h-5 w-5" />
                                View Full Report
                            </Button>
                        </Link>
                    </div>
                </div>
            )}
        </div>
    );
}
