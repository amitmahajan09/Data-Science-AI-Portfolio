'use client';

import { useState } from 'react';
import Link from 'next/link';
import { MoreHorizontal, Eye, Download, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { exportToCsv } from '@/app/actions';
import * as XLSX from 'xlsx';

interface ReportActionsProps {
  runId: string;
}

export default function ReportActions({ runId }: ReportActionsProps) {
  const [isExporting, setIsExporting] = useState(false);
  const { toast } = useToast();

  const handleExport = async (format: 'csv' | 'xlsx') => {
    setIsExporting(true);
    try {
      const { csv, error } = await exportToCsv(runId);

      if (error || !csv) {
        toast({
          title: 'Export Failed',
          description: error || 'Could not generate file.',
          variant: 'destructive',
        });
        return;
      }

      const fileName = `reconciliation-report-${runId.split('-')[1]}`;

      if (format === 'csv') {
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.setAttribute('download', `${fileName}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      } else {
        // xlsx
        const worksheet = XLSX.utils.json_to_sheet(
          XLSX.utils.sheet_to_json(XLSX.read(csv, { type: 'string' }).Sheets.Sheet1)
        );
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Report');
        XLSX.writeFile(workbook, `${fileName}.xlsx`);
      }
    } catch (e: any) {
      toast({
        title: 'Export Failed',
        description: e.message,
        variant: 'destructive',
      });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" disabled={isExporting}>
          {isExporting ? <Loader2 className="h-4 w-4 animate-spin" /> : <MoreHorizontal className="h-4 w-4" />}
          <span className="sr-only">Actions</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem asChild>
          <Link href={`/dashboard/reports/${runId}`}>
            <Eye className="mr-2 h-4 w-4" />
            <span>View Report</span>
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem onSelect={() => handleExport('csv')}>
          <Download className="mr-2 h-4 w-4" />
          <span>Download CSV</span>
        </DropdownMenuItem>
        <DropdownMenuItem onSelect={() => handleExport('xlsx')}>
          <Download className="mr-2 h-4 w-4" />
          <span>Download XLSX</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
