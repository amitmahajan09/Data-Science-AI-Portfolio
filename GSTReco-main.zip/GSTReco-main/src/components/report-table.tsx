

'use client';

import { useState, useMemo, useEffect } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import type { ReconciliationResult, ReconciliationStatus } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Card, CardContent } from './ui/card';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { AlertCircle, Info } from 'lucide-react';
import { Button } from './ui/button';
import { useToast } from '@/hooks/use-toast';

interface ReportTableProps {
  initialData: ReconciliationResult[];
}

const statusConfig: Record<ReconciliationStatus, { variant: 'default' | 'secondary' | 'destructive' | 'outline', color: string }> = {
    'Matched': { variant: 'outline', color: 'border-green-500 text-green-700' },
    'Mismatched': { variant: 'outline', color: 'border-orange-500 text-orange-700' },
    'Missing in 2B': { variant: 'destructive', color: '' },
    'Extra in 2B': { variant: 'outline', color: 'border-blue-500 text-blue-700' },
    'All': { variant: 'default', color: '' },
};


export default function ReportTable({ initialData }: ReportTableProps) {
  const [filter, setFilter] = useState<ReconciliationStatus>('All');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredData = useMemo(() => {
    const term = searchTerm.toLowerCase();
    return initialData
      .filter(item => filter === 'All' || item.status === filter)
      .filter(item => {
        if (!term) return true;
        const invoice = item.internal || item.gstr2b;
        return (
          invoice?.documentNumber?.toLowerCase().includes(term) ||
          invoice?.supplierGstin?.toLowerCase().includes(term) ||
          invoice?.supplierName?.toLowerCase().includes(term)
        );
      });
  }, [initialData, filter, searchTerm]);

  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-center justify-between gap-4 mb-4">
            <Tabs value={filter} onValueChange={(value) => setFilter(value as ReconciliationStatus)}>
                <TabsList>
                    <TabsTrigger value="All">All</TabsTrigger>
                    <TabsTrigger value="Matched">Matched</TabsTrigger>
                    <TabsTrigger value="Mismatched">Mismatched</TabsTrigger>
                    <TabsTrigger value="Missing in 2B">Missing in 2B</TabsTrigger>
                    <TabsTrigger value="Extra in 2B">Extra in 2B</TabsTrigger>
                </TabsList>
            </Tabs>
            <Input
                placeholder="Filter results..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-sm"
            />
        </div>
        <div className="rounded-md border">
          <TooltipProvider>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Status</TableHead>
                  <TableHead>Invoice #</TableHead>
                  <TableHead>Supplier Name</TableHead>
                  <TableHead>Supplier GSTIN</TableHead>
                  <TableHead>Date (Int)</TableHead>
                  <TableHead>Date (2B)</TableHead>
                  <TableHead className="text-right">Value (Int)</TableHead>
                  <TableHead className="text-right">Value (2B)</TableHead>
                  <TableHead>Alert</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredData.length > 0 ? (
                  filteredData.map((item, index) => {
                    const config = statusConfig[item.status as Exclude<ReconciliationStatus, 'All'>];
                    const inv = item.internal || item.gstr2b;
                    
                    const getAlertIcon = (priority: 'High' | 'Medium' | 'Low' | 'None' | undefined) => {
                        switch (priority) {
                            case 'High': return <AlertCircle className="h-4 w-4 text-red-500 shrink-0" />;
                            case 'Medium': return <AlertCircle className="h-4 w-4 text-orange-500 shrink-0" />;
                            case 'Low': return <Info className="h-4 w-4 text-blue-500 shrink-0" />;
                            default: return null;
                        }
                    }

                    return (
                      <TableRow key={inv?.id || index}>
                        <TableCell>
                          <Badge variant={config.variant} className={cn(config.color)}>
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-medium">{inv?.documentNumber}</TableCell>
                        <TableCell>{inv?.supplierName || '-'}</TableCell>
                        <TableCell>{inv?.supplierGstin}</TableCell>
                        <TableCell>{item.internal?.invoiceDate || '-'}</TableCell>
                        <TableCell>{item.gstr2b?.invoiceDate || '-'}</TableCell>
                        <TableCell className="text-right">₹{item.internal?.taxableValue?.toFixed(2) || '-'}</TableCell>
                        <TableCell className="text-right">₹{item.gstr2b?.taxableValue?.toFixed(2) || '-'}</TableCell>
                        <TableCell>
                          {item.alert && item.alert.priority !== 'None' ? (
                             <Tooltip>
                                <TooltipTrigger asChild>
                                    <div className="flex items-center gap-2 cursor-pointer">
                                        {getAlertIcon(item.alert.priority)}
                                        <span className="truncate max-w-xs">{item.alert.message}</span>
                                    </div>
                                </TooltipTrigger>
                                <TooltipContent className="max-w-md bg-card border-primary">
                                    <p className='font-bold mb-1'>Priority: {item.alert.priority}</p>
                                    <p>{item.alert.message}</p>
                                </TooltipContent>
                            </Tooltip>
                          ) : (
                            <span className="text-xs text-muted-foreground">-</span>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })
                ) : (
                  <TableRow>
                    <TableCell colSpan={13} className="h-24 text-center">
                      No results found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TooltipProvider>
        </div>
      </CardContent>
    </Card>
  );
}
