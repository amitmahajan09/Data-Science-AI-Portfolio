'use client';

import type { ReconciliationResult } from '@/lib/types';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import ReportTable from './report-table';
import { SearchProvider } from '@/context/search-context';

interface SearchResultsDialogProps {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  results: ReconciliationResult[];
  query: string;
}

export default function SearchResultsDialog({
  isOpen,
  onOpenChange,
  results,
  query,
}: SearchResultsDialogProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-full w-full h-[95vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>
            Smart Search Results for: <span className="text-primary">{query}</span>
          </DialogTitle>
          <DialogDescription>
            Found {results.length} invoices matching your query. You can further refine these results.
          </DialogDescription>
        </DialogHeader>
        <div className="flex-grow overflow-auto">
            <SearchProvider>
                 {results.length > 0 ? (
                    <ReportTable initialData={results} />
                ) : (
                    <div className="flex items-center justify-center h-full text-muted-foreground">
                        No results found.
                    </div>
                )}
            </SearchProvider>
        </div>
      </DialogContent>
    </Dialog>
  );
}
