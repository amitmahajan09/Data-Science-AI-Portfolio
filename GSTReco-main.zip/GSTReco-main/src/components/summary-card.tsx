import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
  } from "@/components/ui/card"
import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";
  
  interface SummaryCardProps {
    title: string;
    value: string;
    icon: LucideIcon;
    valueClassName?: string;
  }
  
  export default function SummaryCard({ title, value, icon: Icon, valueClassName }: SummaryCardProps) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">{title}</CardTitle>
          <Icon className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className={cn("text-2xl font-bold", valueClassName)}>{value}</div>
        </CardContent>
      </Card>
    );
  }
  