
'use client';

import { createContext, useContext, useState, type ReactNode, useEffect } from 'react';

export type Organization = {
  id: string;
  name: string;
  adminEmail: string;
  status: 'Active' | 'Inactive';
  createdAt: string;
};

type OrganizationContextType = {
  organizations: Organization[];
  setOrganizations: React.Dispatch<React.SetStateAction<Organization[]>>;
  selectedOrganization: Organization | null;
  setSelectedOrganization: (org: Organization) => void;
  addOrganization: (orgData: Omit<Organization, 'id' | 'status' | 'createdAt'>) => void;
  updateOrganization: (updatedOrg: Organization) => void;
};

const mockInitialOrganizations: Organization[] = [
   {
    id: "org_admin_01",
    name: "GST Ace Admin",
    adminEmail: "super@gstace.com",
    status: "Active",
    createdAt: "2023-01-01",
  },
  {
    id: "org_1",
    name: "Innovate Inc.",
    adminEmail: "admin@innovate.com",
    status: "Active",
    createdAt: "2023-01-15",
  },
  {
    id: "org_2",
    name: "Solutions Corp.",
    adminEmail: "contact@solutions.co",
    status: "Active",
    createdAt: "2023-02-20",
  },
  {
    id: "org_3",
    name: "Synergy LLC",
    adminEmail: "support@synergy.llc",
    status: "Inactive",
    createdAt: "2023-03-10",
  },
  {
    id: "org_4",
    name: "Quantum Leap",
    adminEmail: "ceo@quantum.com",
    status: "Active",
    createdAt: "2023-05-01",
  },
];

const ORG_STORAGE_KEY = 'gst-ace-organizations';

const OrganizationContext = createContext<OrganizationContextType | undefined>(undefined);

export function OrganizationProvider({ children }: { children: ReactNode }) {
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [selectedOrganization, setSelectedOrganizationState] = useState<Organization | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load organizations from localStorage on mount
  useEffect(() => {
    try {
      const savedOrgs = localStorage.getItem(ORG_STORAGE_KEY);
      const initialOrgs = savedOrgs ? JSON.parse(savedOrgs) : mockInitialOrganizations;
      setOrganizations(initialOrgs);

      // Set default selected org based on loaded data
      const defaultOrg = initialOrgs.find((o: Organization) => o.id === 'org_admin_01') || initialOrgs[0];
      setSelectedOrganizationState(defaultOrg);

    } catch (error) {
      console.error("Failed to load organizations from localStorage", error);
      setOrganizations(mockInitialOrganizations);
       const defaultOrg = mockInitialOrganizations.find((o: Organization) => o.id === 'org_admin_01') || mockInitialOrganizations[0];
      setSelectedOrganizationState(defaultOrg);
    }
    setIsLoaded(true);
  }, []);

  // Save organizations to localStorage whenever they change
  useEffect(() => {
    if (isLoaded) {
      try {
        localStorage.setItem(ORG_STORAGE_KEY, JSON.stringify(organizations));
      } catch (error) {
        console.error("Failed to save organizations to localStorage", error);
      }
    }
  }, [organizations, isLoaded]);
  
  const setSelectedOrganization = (org: Organization) => {
    setSelectedOrganizationState(org);
  };
  
  const addOrganization = (orgData: Omit<Organization, 'id' | 'status' | 'createdAt'>) => {
    const newOrg: Organization = {
      ...orgData,
      id: `org_${Date.now()}`,
      status: "Active",
      createdAt: new Date().toISOString().split('T')[0],
    };
    setOrganizations(prevOrgs => [newOrg, ...prevOrgs]);
  };
  
  const updateOrganization = (updatedOrg: Organization) => {
    setOrganizations(prevOrgs =>
      prevOrgs.map(org => (org.id === updatedOrg.id ? updatedOrg : org))
    );
    // If the edited org is the currently selected one, update the selected org state as well
    if (selectedOrganization?.id === updatedOrg.id) {
        setSelectedOrganizationState(updatedOrg);
    }
  };


  const value = {
    organizations,
    setOrganizations,
    selectedOrganization,
    setSelectedOrganization,
    addOrganization,
    updateOrganization,
  };

  // Prevent rendering children until state is loaded to avoid hydration mismatches
  if (!isLoaded) {
    return null; 
  }

  return (
    <OrganizationContext.Provider value={value}>
      {children}
    </OrganizationContext.Provider>
  );
}

export function useOrganizations() {
  const context = useContext(OrganizationContext);
  if (context === undefined) {
    throw new Error('useOrganizations must be used within an OrganizationProvider');
  }
  return context;
}
