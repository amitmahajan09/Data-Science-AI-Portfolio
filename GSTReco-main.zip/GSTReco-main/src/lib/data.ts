
export const requiredFields = [
  { id: 'documentNumber', label: 'Invoice Number', commonVariations: ['Invoice No', 'Invoice No.', 'Document Number', 'Supplier Invoice Num'] },
  { id: 'supplierGstin', label: 'Supplier GSTIN', commonVariations: ['GSTIN', 'Supplier GSTIN', 'BSP GSTN Number'] },
  { id: 'supplierName', label: 'Supplier Name', commonVariations: ['Supplier Name', 'Supplier Legal Name', 'Vendor Name'] },
  { id: 'invoiceDate', label: 'Invoice Date', commonVariations: ['Date', 'Invoice Date', 'Document Date', 'Supplier Invoice Date'] },
  { id: 'taxableValue', label: 'Taxable Value', commonVariations: ['Taxable', 'Taxable Value', 'Taxable Amount', 'Sum of Taxable Amt', 'Total Taxable Value'] },
  { id: 'igst', label: 'IGST', commonVariations: ['IGST', 'IGST Amount', 'Integrated Tax'] },
  { id: 'cgst', label: 'CGST', commonVariations: ['CGST', 'CGST Amount', 'Central Tax'] },
  { id: 'sgst', label: 'SGST', commonVariations: ['SGST', 'SGST Amount', 'State Tax'] },
  { id: 'totalTax', label: 'Total Tax', commonVariations: ['Tax', 'Total Tax', 'Total Tax Value', 'Sum of TotalGST', 'Total GST'] },
];

