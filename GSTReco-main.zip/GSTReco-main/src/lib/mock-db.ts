'use server';

import type { ReconciliationOutput, SavedReconciliationRun } from './types';

// This is an in-memory store, so it will be reset on every server restart.
// In a real application, this would be a database.
let reconciliationRuns: SavedReconciliationRun[] = global.reconciliationRuns || [];
if (process.env.NODE_ENV !== 'production') {
    global.reconciliationRuns = reconciliationRuns;
}

interface SaveRunInput {
    orgId: string;
    summary: ReconciliationOutput['summary'];
    results: ReconciliationOutput['results'];
}

// Function to save a new reconciliation run
export async function saveReconciliationRun({ orgId, summary, results }: SaveRunInput): Promise<SavedReconciliationRun> {
    const newRun: SavedReconciliationRun = {
        id: `run-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
        orgId: orgId,
        runDate: new Date().toISOString(),
        user: 'Demo User', // In a real app, this would come from session
        data: {
            summary,
            results,
        },
    };

    // Add to the beginning of the array to have the newest first
    reconciliationRuns.unshift(newRun);
    
    console.log(`Saved run ${newRun.id} for org ${orgId}. Total runs in memory: ${reconciliationRuns.length}`);
    return newRun;
}

// Function to get all reconciliation runs for a specific organization
export async function getReconciliationRuns(orgId: string): Promise<SavedReconciliationRun[]> {
    const runsForOrg = reconciliationRuns.filter(run => run.orgId === orgId);
    console.log(`Retrieving runs for org ${orgId}. Found: ${runsForOrg.length}`);
    return runsForOrg;
}

// Function to get a single reconciliation run by its ID
export async function getReconciliationRun(id: string): Promise<SavedReconciliationRun | undefined> {
    const run = reconciliationRuns.find(run => run.id === id);
    console.log(`Searching for run with id: ${id}. Found: ${!!run}`);
    return run;
}
