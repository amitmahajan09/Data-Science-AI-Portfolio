

export type Invoice = {
  id: string;
  supplierGstin: string;
  supplierName?: string;
  documentNumber: string;
  invoiceDate: string; // YYYY-MM-DD
  taxableValue: number;
  igst?: number;
  cgst?: number;
  sgst?: number;
  totalTax: number;
};

export type ReconciliationStatus = 'Matched' | 'Mismatched' | 'Missing in 2B' | 'Extra in 2B' | 'All';

export type ReconciliationResult = {
  status: ReconciliationStatus;
  internal?: Invoice;
  gstr2b?: Invoice;
  alert?: {
    priority: 'High' | 'Medium' | 'Low' | 'None';
    message: string;
  };
};

export type ReconciliationSummary = {
  totalInvoices: number;
  matched: number;
  mismatched: number;
  missingIn2B: number;
  extraIn2B: number;
}

export type ReconciliationOutput = {
  summary: ReconciliationSummary;
  results: ReconciliationResult[];
};

export type ColumnMapping = {
  [key: string]: string;
};

export type SavedReconciliationRun = {
  id: string;
  orgId: string;
  runDate: string;
  user: string;
  data: ReconciliationOutput;
}


// --- AI Flow Types ---
export type SmartSearchOutput = {
    status?: ('Matched' | 'Mismatched' | 'Missing in 2B' | 'Extra in 2B')[];
    amountGreaterThan?: number;
    amountLessThan?: number;
    startDate?: string;
    endDate?: string;
    supplierGstin?: string;
    documentNumber?: string;
    textSearch?: string;
};
